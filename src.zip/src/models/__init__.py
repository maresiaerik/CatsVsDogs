from models.abstract.model import Model
from models.cnn import CNN
from models.alexnet import AlexNet
from models.vgg16 import VGG16
